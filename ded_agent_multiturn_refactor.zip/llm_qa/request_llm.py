import requests
from google import genai
import os

# API_KEY = "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"
API_KEY = "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"
os.environ['API_KEY'] = API_KEY
def request_gpt(prompt, api_key, model="gpt-5-mini", temperature=1):
    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    data = {
        "model": model,
        "messages": [
            {"role": "system", "content": "You are an ophthalmology expert specializing in orthokeratology (OK) lens fitting and follow-up."},
            {"role": "user", "content": prompt}
        ],
        "temperature": temperature,
    }
    try:
        response = requests.post(url, headers=headers, json=data, timeout=100)

        if response.status_code == 200:
            return response.json()
        else:
            return response.text
    except:
        return ""
    
def dp_answer(prompt):
    api_key = os.getenv("API_KEY")
    response = request_gpt(prompt, api_key, "gpt-5")
    try:
        raw_text = response['choices'][0]['message']['content']
    except:
        raw_text = ""
    return raw_text
    

def request_gemini(content):
    client = genai.Client(api_key="Your_Gemini_Key")
    try:
        response = client.models.generate_content(
            model="gemini-2.0-flash", contents=content
        )
        return(response.text)
    except:
        return "no result"

